from django.contrib import admin
from .models import Person,Education

# Register your models here.
admin.site.register(Person)
admin.site.register(Education)
