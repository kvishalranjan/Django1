from django.contrib import admin
from .models import Contactinfo
# Register your models here.

admin.site.register(Contactinfo)